package entities;

public interface Shape {

	double area();
}
