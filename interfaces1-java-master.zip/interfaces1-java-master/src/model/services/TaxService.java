package model.services;

public interface TaxService {

	double tax(double amount);
}
