package devices;

public interface Printer {

	void print(String doc);
}
